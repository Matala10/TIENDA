// Variables
let baseDeDatos = [
    {
        id: 1,
        nombre: 'Macbook Air 13',
        precio: 1099,
        imagen: 'macbookair.jpg'
    },
    {
        id: 2,
        nombre: 'iPhone 12 Pro',
        precio: 1249,
        imagen: 'iPhone%2012.jpg'
    },
    {
        id: 3,
        nombre: 'iPad Pro',
        precio: 840,
        imagen: 'iPad%20Pro.jpg'
    },
    {
        id: 4,
        nombre: 'Watch Series 6',
        precio: 349,
        imagen: 'apple%20watch%20series%206.jpg'
    },
    {
        id: 5,
        nombre: 'Airpods Pro',
        precio: 279,
        imagen: 'Airpods%20Pro.jpg'
    },
    {
        id: 6,
        nombre: 'Macbook Pro 13"',
        precio: 1299,
        imagen: 'macbookpro.jpg'
    },
    {
        id: 7,
        nombre: 'iPhone 11',
        precio: 749,
        imagen: 'iphone11.jpg'
    },
    {
        id: 8,
        nombre: 'iPad Air',
        precio: 549,
        imagen: 'ipadair.jpg'
    },
    {
        id: 9,
        nombre: 'Watch Series 5',
        precio: 469,
        imagen: 'applewatchseries5.jpg'
    },
    {
        id: 10,
        nombre: 'Airpods con carga inalámbrica',
        precio: 199,
        imagen: 'airpodscargainalambrica.jpg'
    },
    {
        id: 11,
        nombre: 'Macbook Pro 15"',
        precio: 1499,
        imagen: 'macbookpro15.jpg'
    },
    {
        id: 12,
        nombre: 'iPhone SE 2020',
        precio: 489,
        imagen: 'iphonese.jpg'
    },
    {
        id: 13,
        nombre: 'iPad 2020',
        precio: 379,
        imagen: 'ipad2020.jpg'
    },
    {
        id: 14,
        nombre: 'Watch Series 4',
        precio: 399,
        imagen: 'applewatchseries4.jpg'
    },
    {
        id: 15,
        nombre: 'Airpods',
        precio: 139,
        imagen: 'airpods.jpg'
    }
];

let $agregar = document.querySelector('#agregar');
let $items = document.querySelector('#items');
let carrito = [];
let total = 0;
let $carrito = document.querySelector('#carrito');
let $total = document.querySelector('#total');
let $botonVaciar = document.querySelector('#boton-vaciar');

// Funciones

function anyadirCarrito(evento) {
    // Anyadimos el Nodo a nuestro carrito
    carrito.push(evento.target.dataset.pk);
    // Guardamos en localstorage
    guardarCarritoLocalstorage();
    // Alerta al usuario
    alert('Producto añadido al carrito');
}

function guardarCarritoLocalstorage() {
    localStorage.setItem("carrito", JSON.stringify(carrito));
}

function renderizarCarrito() {
    // Vaciamos todo el html
    $carrito.textContent = '';
    // Quitamos los duplicados
    let carritoSinDuplicados = [...new Set(carrito)];
    // Generamos los Nodos a partir de carrito
    carritoSinDuplicados.forEach(function (item, indice) {
        // Obtenemos el item que necesitamos de la variable base de datos
        let miItem = baseDeDatos.filter(function(itemBaseDatos) {
            return itemBaseDatos['id'] == item;
        });
        // Cuenta el número de veces que se repite el producto
        let numeroUnidadesItem = carrito.reduce(function (total, itemId) {
            return itemId === item ? total += 1 : total;
        }, 0);
        // Creamos el nodo del item del carrito
        let miNodo = document.createElement('li');
        miNodo.classList.add('list-group-item', 'text-right', 'mx-2');
        miNodo.textContent = `${numeroUnidadesItem} x ${miItem[0]['nombre']} - ${miItem[0]['precio']}€`;
        // Boton de borrar
        let miBoton = document.createElement('button');
        miBoton.classList.add('btn', 'btn-danger', 'mx-5');
        miBoton.textContent = 'X';
        miBoton.style.marginLeft = '1rem';
        miBoton.setAttribute('item', item);
        miBoton.addEventListener('click', borrarItemCarrito);
        // Mezclamos nodos
        miNodo.appendChild(miBoton);
        $carrito.appendChild(miNodo);
    });
}

function borrarItemCarrito() {
    // Obtenemos el producto ID que hay en el boton pulsado
    let id = this.getAttribute('item');
    // Borramos todos los productos
    carrito = carrito.filter(function (carritoId) {
        return carritoId !== id;
    });
    // volvemos a renderizar
    renderizarCarrito();
    // Calculamos de nuevo el precio
    renderizarTotal();
    guardarCarritoLocalstorage();
}

function calcularTotal() {
    // Limpiamos precio anterior
    total = 0;
    // Recorremos el array del carrito
    for (let item of carrito) {
        // De cada elemento obtenemos su precio
        let miItem = baseDeDatos.filter(function(itemBaseDatos) {
            return itemBaseDatos['id'] == item;
        });
        total = total + miItem[0]['precio'];
    }
    // Formateamos el total para que solo tenga dos decimales
    return total.toFixed(2);
}

function renderizarTotal() {
    // Renderizamos el precio en el HTML
    $total.textContent = calcularTotal();
}

function vaciarCarrito() {
    // Limpiamos los productos guardados
    carrito = [];
    // Renderizamos los cambios
    renderizarCarrito();
    renderizarTotal();
}


if($agregar !== null) $agregar.addEventListener('click', anyadirCarrito);

// Carga data de localhost
loadData = JSON.parse(localStorage.getItem("carrito"));

carrito = loadData !== null ? loadData : [];

// Eventos
if($carrito !== null) {
    // Estoy en la página del carrito
    $botonVaciar.addEventListener('click', vaciarCarrito);

    // Inicio
    renderizarCarrito();
    renderizarTotal();
}

// Paypal
paypal.Buttons({
    createOrder: function(data, actions) {
        // This function sets up the details of the transaction, including the amount and line item details.
        return actions.order.create({
            purchase_units: [{
                amount: {
                    value: calcularTotal()
                }
            }]
        });
    },
    onApprove: function(data, actions) {
        // This function captures the funds from the transaction.
        return actions.order.capture().then(function(details) {
            // This function shows a transaction success message to your buyer.
            alert('Pago completado ' + details.payer.name.given_name);
        });
    }
}).render('#paypal-button-container');
