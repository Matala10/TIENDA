$(function() { 
  $('#miForm').on('submit', function(e) { 
    e.preventDefault();
  var jsonData=$(this).serializeArray()
    .reduce(function(a, z) { a[z.name] = z.value; return a; }, {});
    console.log(jsonData);
  });
});
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<form action="" method="post" class="form_contact" id="miForm">
  <h2>DATOS DE CONTACTO</h2>
  <div class="user_info">

    <label for="dni_number">Numero de identificación</label>
    <td><input type="text" name="dni" id="dni_number" value="1" /></td>

    <label for="nombreyapellido">Nombre y Apellido</label>
    <td><input type="text" name="full_name" value="Pedro Pérez" /></td>

    <label for="contact_phone">Celular</label>
    <td><input type="tel" name="contact_phone" value="633555555" /></td>

    <label for="email_address">Correo Electrónico</label>
    <td><input type="email" name="email_address" value="uncorreo@mail.com" /></td>
    <br>

    <input type="submit" value="Enviar" id="btnSend">

  </div>
</form>

kkkkkkkkkk