<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>formulario de contactar - Mensaje enviado</title>
</head>
<body>
	<center>
		<h1>Contactar</h1>
		<?php 
			$myemail = 'el_vacilon_m@hotmail.com';
			$name = $_POST['nombre'];
			$email = $_POST['email'];
			$message = $_POST['mensaje'];

			$to = $myemail;
			$email_subject = "Nuevo mensaje: $subject";
			$email_body = "Haz recibido un nuevo mensaje. \n Nombre: $name \n Correo: $email \n Mensaje: \n $message";
			$headers = "From: $email";

			mail($to, $email_subject, $email_body, $headers);
			echo "El mensaje se ha enviado correctamente";
		?>
		<form method="post" action="enviar.php">
			<input type="text" name="nombre" placeholder="NOMBRE">
			<br>
			<input type="email" name="email" placeholder="CORREO">
			<textarea type="text" name="mensaje" placeholder="MENSAJE"></textarea>
			<br>
			<input type="submit" value="ENVIAR">
		</form>
	</center>
</body>
</html>